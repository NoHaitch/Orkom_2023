void Beginning(char* input){
    if(strings_not_equal(input, "In this universe, on this vast planet, I was able to meet you")){
        illegal_move();
    } 
    return;
}
